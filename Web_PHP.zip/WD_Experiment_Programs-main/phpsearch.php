<?php 

//Searching in Assossiative Array

echo "<br>"."Assossiative Array";
$array = array(0 => 'blue', 1 => 'red', 2 => 'green', 3 => 'red');

$key = array_search('green', $array);
echo "$key";
echo "<br>";
$key = array_search('red', $array); 
echo "$key";

echo "<br>"."Indexed Array";


//Searching in Indexed Array

$array1 = array(6,2,7,1,3);

$key1= array_search(1,$array1);

$key2 = array_search(3,$array1);

echo "$key1";
echo "<br>";
echo "$key2";

?>