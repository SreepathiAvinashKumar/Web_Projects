<?php
$servername = "localhost";
$username = "root";
$password = "";
$db  = "anan";

$conn = mysqli_connect($servername,$username,$password, $db);

// used to create the connection
if(!$conn){
echo "conncetion is Failed!".mysqli_error($conn);
}
else {
echo "conncetion is successfull"."<br>";
}



//used to create the database

$sql = "create database AvinDB";


if(mysqli_query($conn,$sql)){
echo "Successful to create the database"."<br>";
}
else{
echo "Failed to create the database".
mysqli_error($conn)."<br>";
}


// used to create the table 
$sql = "CREATE TABLE avindb.mynamesimpledb (
id INT(6) UNSIGNED  PRIMARY KEY,
firstname VARCHAR(30) NOT NULL,
lastname VARCHAR(30) NOT NULL,
email VARCHAR(50)
)";

if (mysqli_query($conn,$sql)){
echo "Successfully created the table"."<br>";
}
else {
echo "Failed to create the table".mysqli_error($conn)."<br>";
}


//used  to insert data into the table

$sql = "insert into avindb.mynamesimpledb(id,firstname,lastname,email) values(12,'avinash','kumar','avinashsripathi4@gmail.com')";

if(mysqli_query($conn,$sql)){
echo "successfully lnserted the data"."<br>";
}
else {
echo  "Failed to insert data ".mysqli_error($conn)."<br>";
}


//used to fetch the data from the table 

$sql = "select id,firstname, lastname,email from avindb.mynamesimpledb";
$result = mysqli_query($conn,$sql);

if (mysqli_num_rows($result) > 0) {
while($row = mysqli_fetch_assoc($result)){

    echo "id is ".$row['id']."firstname is ".$row['firstname']."lastname is ".$row['lastname']."email is" .$row['email']."<br>";
}

}

else{
echo "not successfull to fetch ".mysqli_error($conn)."<br>";

}


mysqli_close($conn);
?>