<?php
$cookiename = "avinashlocation";
$cookievalue = "addanki";


setcookie($cookiename,$cookievalue,time()+(120*1));
 
if(!isset($_COOKIE[$cookiename])){
echo "cookie named".$cookiename . "is not set";
}
else {
echo "cookie named ".$cookiename. "has value ".$_COOKIE[$cookiename];
}



?>

<?php

if(count($_COOKIE)>0){
echo "cokies are there";
}

else {
echo "cookies are not there";
}

?>