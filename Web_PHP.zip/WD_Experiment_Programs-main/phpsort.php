<?php 

$cars   = ("Ferari","Benz","Rolls Royals");

$b = sort($cars);

echo "$b";
 





?>