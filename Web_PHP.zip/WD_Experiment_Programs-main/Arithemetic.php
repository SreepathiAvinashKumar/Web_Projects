<!DOCTYPE html>
<html>
<head>
 <title>Php Arithemetic Operators</title>

</head>

<body>

  <?php 
 $a=8;
 $b=4;

 /*
 Addition is 12
Subtraction is 4
Multiplication is 32
Division is 2
Modulus is 0
Increment of a is 8
Decrement of a is 9
 */

$c = $a + $b;

echo "Addition is $c"."</br>";


$c = $a - $b;
echo "Subtraction is $c"."</br>";

$c = $a * $b;
echo "Multiplication is $c"."</br>";

$c = $a / $b;
echo "Division is $c"."</br>";
$c = $a % $b ;

echo "Modulus is $c"."</br>";

$c = $a--;
echo "Increment of a is $c"."</br>";

$c = $a++;
echo "Decrement of a is $c"."</br>";

 ?>

</body>
</html>