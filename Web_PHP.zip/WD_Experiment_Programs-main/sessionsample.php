<?php 
//used to start the session
session_start();

?>

<?php
//  give the values  to session variables
$_SESSION["name"]= "avinash";
$_SESSION["college"]= "gptaddanki";
?>
<?php
echo "values are created they are </br>";

// to display the session variables
echo "name is". $_SESSION["name"];
echo "college is ".$_SESSION["college"];
?>
<?php
// to  remove the session

session_unset();
?>
